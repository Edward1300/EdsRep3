let img;
let img2;
let gif;

function setup() {
  createCanvas(400, 400);
  colorMode(RGB);
  img = loadImage('cat1.png');
  img2 = loadImage('cat2.png');
  gif = loadImage('skeleton.gif');
  
}

function draw() {
  background(20);
  noStroke();
  fill(66, 135, 245);
  textFont('Helvetica', 50);
  text('hello',150,150);
  image(img,120,10,100,100);
  image(img2,mouseX,mouseY,150,150);
  image(gif,250,mouseY,200,200);
  
}