function setup() {
  createCanvas(800, 800);
  colorMode(RGB, 255);
  angleMode(DEGREES);
}

function draw() {
  background(20);
  mollusk();
  for (var i = 10; i < 20; i += 10) {
    
    push();
    let x = random(100, 700);
    let y = random(100, 700);
    let b = random (100, 700);
    translate(x, y);
    rotate(b);
    scale(1);
    crabthing(x,y);
    pop();
  }
}

function crabthing(x, y) {
  
  fill(255, 0, 60);
  
  noStroke();
  
  rect(0,0,20,60);
  rect(0,100,20,20);
  rect(40,100,40,20);
  rect(20,40,80,20);
  rect(40,20,40,20);
  rect(20,80,80,20);
  rect(20,60,20,20);
  rect(80,60,20,20);
  rect(100,100,20,20);
  rect(100,0,20,60);
  
}

function mollusk() {

  let x = 1+1
  print(x);

}