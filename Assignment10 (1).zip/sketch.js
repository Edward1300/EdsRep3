
function preload(){
  pic = loadImage('Headache.png')
}
function setup() {
  createCanvas(400, 400, WEBGL);
  wordObject = createWord3D("edw4rd",3,width/100,20,true,"Georgia",BOLD);
  pictureObject = createPicture3D(pic,5,0.3,1,true);
}

function draw() {
  background(220);
 wordObject.show()
pictureObject.show()
  
}
